#include <iostream>

int main(void){

	std::cout << "Hallo Welt";
	return(0);

}