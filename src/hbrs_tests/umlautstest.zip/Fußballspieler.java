public class Fußballspieler{
        // just have some utf-8 coded german umlauts äüö 
	int i;
}