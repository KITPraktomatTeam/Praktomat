#include <stdio.h>


float summe(float z1, float z2) {
	return z1 + z2;
}

float differenz(float z1, float z2) {
	return z1 - z2;
}

float produkt(float z1, float z2) {
	return z1 * z2;
}

float quotient(float z1, float z2) {
	return z1 / z2;
}

int runde(float z) {
	float frac = z - (int) z;
	if(frac >= 0.5) {
		return (int) (z + 0.5);
	} else if(frac <= -0.5) {
		return (int) (z - 0.5);
	} else {
		return (int) z;
	}
}

int main() {
	printf("%d\n", runde(-40.5));
	return 0;
}
