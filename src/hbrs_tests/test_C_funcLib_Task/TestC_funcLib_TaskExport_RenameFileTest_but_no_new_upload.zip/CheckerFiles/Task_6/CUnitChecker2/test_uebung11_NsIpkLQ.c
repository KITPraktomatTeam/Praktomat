#include <stdio.h>
#include <string.h>
#include <float.h>
#include "CUnit/Basic.h"
#include <dlfcn.h>

#define MAXTESTS 128



#ifdef CU_ASSERT_FLOAT_EQUAL
#undef CU_ASSERT_FLOAT_EQUAL
#endif
#define CU_ASSERT_FLOAT_EQUAL(actual, expected, txt)                    \
    {                                                                   \
       CU_assertImplementation(                                         \
          (feq(actual, expected)),                                      \
          __LINE__,                                                     \
          txt,                                                          \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }


#ifdef CU_ASSERT_EQUAL
#undef CU_ASSERT_EQUAL
#endif
#define CU_ASSERT_EQUAL(actual, expected, txt)                          \
    {                                                                   \
       CU_assertImplementation(                                         \
          ((actual) == (expected)),                                     \
          __LINE__,                                                     \
          txt,                                                          \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }


#ifdef CU_ASSERT
#undef CU_ASSERT
#endif
#define CU_ASSERT(actual, txt)                                          \
    {                                                                   \
       CU_assertImplementation(                                         \
          ((actual)),                                                   \
          __LINE__,                                                     \
          txt,                                                          \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }


#ifdef CU_ASSERT_STRING_EQUAL
#undef CU_ASSERT_STRING_EQUAL
#endif
#define CU_ASSERT_STRING_EQUAL(actual, expected)                        \
    {                                                                   \
        char *_s = "CU_ASSERT_STRING_EQUAL(\"%s\", \"%s\")";            \
        unsigned int _l = strlen(actual) + strlen(expected) +           \
            strlen(_s) - 4 + 1;                                         \
        char _buf[_l];                                                  \
        _buf[_l]='\0';                                                  \
        snprintf(_buf, _l, _s, actual, expected);                       \
        CU_assertImplementation(                                        \
          !(strcmp((const char*)(actual), (const char*)(expected))),    \
           __LINE__,                                                    \
          _buf,                                                         \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }

typedef struct {
    const char  *name;
    CU_TestFunc func;
} t_test;


t_test tests[MAXTESTS] = {{NULL, NULL}};
t_test *current_test = tests;

void add_tests(void);

int
add_test(const char *name, CU_TestFunc func) {

    if (current_test-tests == MAXTESTS) {
        return -1;
    }

    current_test++;
    current_test->name = name;
    current_test->func = func;

    return 0;

} /* add_test */

/* It's a start... */
int
feq(float x, float y) {

    float max_rel_diff = FLT_EPSILON;
    float diff = fabs(x-y);
    x = fabs(x);
    y = fabs(y);

    float largest = (y > x) ? y : x;

    if (diff <= largest * max_rel_diff)
        return 1;

    return 0;

} /* feq */

int
main(int argc __attribute((__unused__)),
     char **argv __attribute((__unused__))) {

    CU_pSuite suite = NULL;
    int err;


    if (CUE_SUCCESS != CU_initialize_registry())
        return CU_get_error();

    suite = CU_add_suite("Tests", NULL, NULL);
    if (NULL == suite) {
        err = CU_get_error();
        CU_cleanup_registry();
        return err;
    }

    add_tests();

    t_test *t = tests;
    while (t++ < current_test) {
        if ((NULL == CU_add_test(suite, t->name, t->func))) {
            err = CU_get_error();
            CU_cleanup_registry();
            return err;
        }
    }


    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    return CU_get_number_of_failures();

} /* main */

float summe(float, float);
float differenz(float, float);
float produkt(float, float);
float quotient(float, float);
#if 0
int runden(float);
int runde(float);
#endif

void
test_sum(void) {

    float res;

    res = summe(0, 0);
    CU_ASSERT_FLOAT_EQUAL(res, 0, "summe(0, 0)");

    res = summe(-42.42, 42.42);
    CU_ASSERT_FLOAT_EQUAL(res, 0, "summe(-42.42, 42.42)");

    res = summe(-FLT_MAX, (float)1e10);
    CU_ASSERT_FLOAT_EQUAL(res, (-FLT_MAX + (float)1e10),
                          "summe(-FLT_MAX, (float)1e10)");

} /* test_sum */


void
test_diff(void) {

    float res;

    res = differenz(0, 0);
    CU_ASSERT_FLOAT_EQUAL(res, 0, "differenz(0, 0)");

    res = differenz(-42.42, 42.42);
    CU_ASSERT_FLOAT_EQUAL(res, -84.84, "differenz(-42.42, 42.42)");

    res = differenz(FLT_MAX, (float)1e10);
    CU_ASSERT_FLOAT_EQUAL(res, (FLT_MAX - (float)1e10),
                          "differenz(FLT_MAX, (float)1e10)");

} /* test_diff */


void
test_produkt(void) {

    float res;

    res = produkt(0, 0);
    CU_ASSERT_FLOAT_EQUAL(res, 0, "produkt(0, 0)");

    res = produkt(0, -0);
    CU_ASSERT_FLOAT_EQUAL(res, 0, "produkt(0, -0)");

    res = produkt(-42.42, 0);
    CU_ASSERT_FLOAT_EQUAL(res, 0, "produkt(-42.42, 0)");

    res = produkt(42.42, 0);
    CU_ASSERT_FLOAT_EQUAL(res, 0, "produkt(42.42, 0)");

    res = produkt(42.42, 4.5);
    CU_ASSERT_FLOAT_EQUAL(res, (42.42*4.5), "produkt(42.42, 4.5)");

    res = produkt(42.42, -4.5);
    CU_ASSERT_FLOAT_EQUAL(res, (42.42*-4.5), "produkt(42.42, -4.5)");

    res = produkt(-42.42, -42.42);
    CU_ASSERT_FLOAT_EQUAL(res, (-42.42*-42.42), "produkt(-42.42, -42.42)");

} /* test_produkt */


void
test_quotient_div_zero(void) {

    float res;

    res = quotient(42.42, 0);

    if (res != 0.0) {
    printf("\nquotient(x, 0) should indicate a division by 0... ");
      CU_PASS("quotient(x, 0) should indicate a division by 0");
    } else {
      CU_ASSERT_FLOAT_EQUAL(res, 0, "quotient(42.42, 0)");
    }

} /* test_quotient_div_zero */


void
test_quotient(void) {

    float res;

    res = quotient(-42.42, 42.42);
    CU_ASSERT_FLOAT_EQUAL(res, -1, "quotient(-42.42, 42.42)");

    res = quotient(42.42, -42.42);
    CU_ASSERT_FLOAT_EQUAL(res, -1, "quotient(42.42, -42.42)");

    res = quotient(42.42, 42.42);
    CU_ASSERT_FLOAT_EQUAL(res, 1, "quotient(42.42, 42.42)");


} /* test_quotient */


/*
  There is an inconsistency naming the function. To work
  around that we first try to load runden(float) and if that 
  fails, runde(float). This should be fixed later...
*/
void
test_runden2() {
    void *handle = NULL;
    int (*r)(float);
    char *error;
    int res;
 
    handle = dlopen( "./libSolution.so" , RTLD_LAZY|RTLD_DEEPBIND);
    if (handle == NULL) {
        CU_FAIL("Internal error: could not find libSolution.so");
        return;
    }

    r = dlsym(handle, "runden");
    if ((error = dlerror()) != NULL)  {
        r = dlsym(handle, "runde");
        if ((error = dlerror()) != NULL)  {
            CU_FAIL("Neither runde(float) nor runden(float) could be found.");
            return;
        }

    }

    res = r(0.0);
    CU_ASSERT_EQUAL(res, 0, "runden(0.0)");

    res = r(-42.42);
    CU_ASSERT_EQUAL(res, -42, "runden(-42.42)");
  
    res = r(-42.50);
    CU_ASSERT_EQUAL(res, -43, "runden(-42.50)");

    res = r(42.42);
    CU_ASSERT_EQUAL(res, 42, "runden(42.42)");

    res = r(42.50);
    CU_ASSERT_EQUAL(res, 43, "runden(42.50)");
    
} /* test_runden2 */
    
#if 0
void
test_runden(void) {

  int res;

  res = runden(0.0);
  CU_ASSERT_EQUAL(res, 0, "runden(0.0)");

  res = runden(-42.42);
  CU_ASSERT_EQUAL(res, -42, "runden(-42.42)");

  res = runden(-42.50);
  CU_ASSERT_EQUAL(res, -43, "runden(-42.50)");

  res = runden(42.42);
  CU_ASSERT_EQUAL(res, 42, "runden(42.42)");

  res = runden(42.50);
  CU_ASSERT_EQUAL(res, 43, "runden(42.50)");

} /* test_runden */
#endif

void
add_tests(void) {

    add_test("test_sum", test_sum);
    add_test("test_diff", test_diff);
    add_test("test_produkt", test_produkt);
    add_test("test_quotient", test_quotient);
    add_test("test_quotient_div_zero", test_quotient_div_zero);
    add_test("test_runden", test_runden2);

} /* add_tests */
