#include "MyThing.h"

  bool MyThing::AssociatedP(MyThingID otherID) { return otherID == this->otherID; } 

