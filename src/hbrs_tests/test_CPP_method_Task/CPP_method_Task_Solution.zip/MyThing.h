#ifndef MYTHING_H
#define MYTHING_H

typedef unsigned char MyThingID;

// A Thing with an associated Thing
class MyThing {
 public:
  // Is this who I'm thinking of?
  bool AssociatedP(MyThingID otherID);
  
  // Constructors are awesome
  MyThing(): otherID(0) {}

 private:
  MyThingID otherID; // Who I'm thinking of
};

#endif /* MYTHING_H */